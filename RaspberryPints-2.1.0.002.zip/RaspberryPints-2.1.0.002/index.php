<?php
/*********************************************************************************
* Description: Display the tap list.
*
* ----- Modification Log -----
*
*  Who: kaljade and Tobor_8thMan collaboration. Both are members of HBT. 
* When: January 2019
*  Why: Update the logic to successfully run in Debian 9.x, php 7.x and MariaDB 10.x.
*
**********************************************************************************/

	if (!file_exists(__DIR__.'/includes/config.php')) {
		header('Location: install/index.php', true, 303);
		die();

	}

	require_once __DIR__.'/includes/config_names.php';
	require_once __DIR__.'/includes/config.php';
	require_once __DIR__.'/admin/includes/managers/tap_manager.php';
	
  /*********************************************************************************
  *     Set processing to use either DB or CSV.
  **********************************************************************************/
	$db = true;
	
  /*********************************************************************************
  *     Setup array for all the beers contained in the list.
  **********************************************************************************/
	$beers = array();
	
	if($db)
	{
    /*********************************************************************************
    *     Connect to the database.
    **********************************************************************************/
		$link = dbRPintsConnect(); //function dbRPintsConnect() is in includes/config.php
		$config = array();
		$sql = "SELECT * FROM config";
    $qry = mysqli_query($link, $sql);

		while($c = mysqli_fetch_array($qry)){
			$config[$c['configName']] = $c['configValue'];
			
		} // ending while($c = mysqli_fetch_array($qry))

		mysqli_free_result($qry); // added new as this wasn't being done.
		$sql =  "SELECT * FROM vwGetActiveTaps";
    $qry = mysqli_query($link, $sql);

		while($b = mysqli_fetch_array($qry))
		{
			$beeritem = array(
				"id" => $b['id'],
				"beername" => $b['name'],
				"style" => $b['style'],
				"notes" => $b['notes'],
				"og" => $b['ogAct'],
				"fg" => $b['fgAct'],
				"srm" => $b['srmAct'],
				"ibu" => $b['ibuAct'],
				"startAmount" => $b['startAmount'],
				"amountPoured" => $b['amountPoured'],
				"remainAmount" => $b['remainAmount'],
				"tapNumber" => $b['tapNumber'],
				"srmRgb" => $b['srmRgb']
			);

			$beers[$b['tapNumber']] = $beeritem;
		} // ending while($b = mysqli_fetch_array($qry))

		mysqli_free_result($qry); // added new as this wasn't being done.
		$tapManager = new TapManager();
		$numberOfTaps = $tapManager->GetTapNumber($link);
	} // ending if($db)

  echo '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">' . "\n";
  echo '<html>' . "\n";
  echo '<head>' . "\n";
  echo '<title>RaspberryPints</title>' . "\n";
  echo '<meta http-equiv="Content-Type" content="text/html; charset=utf-8">' . "\n";
	// <!-- Set location of Cascading Style Sheet -->
  echo '<link rel="stylesheet" type="text/css" href="style.css">' . "\n";
		
  if($config[ConfigNames::UseHighResolution])
  { 
    echo '<link rel="stylesheet" type="text/css" href="high-res.css">' . "\n";
		
  }
		
  echo '<link rel="shortcut icon" href="img/pint.ico">' . "\n";
  echo '</head>' . "\n";
  echo '<body>' . "\n";
  echo '<div class="bodywrapper">' . "\n";
//			<!-- Header with Brewery Logo and Project Name -->
  echo '<div class="header clearfix">' . "\n";
  echo '<div class="HeaderLeft">' . "\n";

//$output = '<a href="admin/admin.php"><img src="' . $config[ConfigNames::LogoUrl] . "?" . time() . '" height="';
  $output = '<a href="admin/admin.php"><img src="' . $config[ConfigNames::LogoUrl] . '" height="';
  $output .= ($config[ConfigNames::UseHighResolution]) ? '200' : '100';
  $output .= '"  alt=""></a>' . "\n";
  echo $output;
	
	echo '</div>' . "\n";
	echo '<div class="HeaderCenter">' . "\n";
	echo '<h1 id="HeaderTitle">' . "\n";
  $output = (mb_strlen($config[ConfigNames::HeaderText], 'UTF-8') > ($config[ConfigNames::HeaderTextTruncLen])) ? substr($config[ConfigNames::HeaderText],0,$config[ConfigNames::HeaderTextTruncLen]) . "..." : $config[ConfigNames::HeaderText];
  echo $output . "\n";
	
	echo '</h1>' . "\n";
	echo '</div>' . "\n";
	echo '<div class="HeaderRight" style="padding-top:1cm;">' . "\n";
  $output = '<a href="http://www.raspberrypints.com"><img src="img/';
	$output .= ($config[ConfigNames::UseHighResolution]) ? 'RaspberryPints-4k.png" height="200"' : 'RaspberryPints.png" height="32"';
	$output .= ' alt=""></a>' . "\n";
	echo $output;
	
	echo '</div>' . "\n";
	echo '</div>' . "\n";
//			<!-- End Header Bar -->
	echo '<table>' . "\n";
	echo '<thead>' . "\n";
	echo '<tr>' . "\n";
	
	if($config[ConfigNames::ShowTapNumCol])
	{
    /*********************************************************************************
    *     Tap number header.
    **********************************************************************************/
	  echo '<th class="tap-num">TAP<br />#</th>' . "\n";

	}
						
	if($config[ConfigNames::ShowSrmCol])
	{
    /*********************************************************************************
    *     SRM header.
    **********************************************************************************/
	  echo '<th class="srm">GRAVITY<hr>COLOR</th>' . "\n";

	}
						
	if($config[ConfigNames::ShowIbuCol])
	{
    /*********************************************************************************
    *     IBU header.
    **********************************************************************************/
	  echo '<th class="ibu">BALANCE<hr>BITTERNESS</th>' . "\n";

	}
				
	echo '<th class="name">BEER NAME &nbsp; & &nbsp; STYLE<hr>TASTING NOTES</th>' . "\n";
						
	if($config[ConfigNames::ShowAbvCol])
	{
    /*********************************************************************************
    *     ABV header.
    **********************************************************************************/
	  echo '<th class="abv">CALORIES<hr>ALCOHOL</th>' . "\n";

	}
						
	if($config[ConfigNames::ShowKegCol])
	{
    /*********************************************************************************
    *     Keg header.
    **********************************************************************************/
	  echo '<th class="keg">POURED<hr>REMAINING</th>' . "\n";

	}
	
	echo '</tr></thead><tbody>' . "\n";

	for($i = 1; $i <= $numberOfTaps; $i++)
	{
    /*********************************************************************************
    *     Loop thru and render the tap data.
    **********************************************************************************/
		$haveData = (isset($beers[$i])) ? true : false;
		
		if ($haveData)
		{
	    $beer = $beers[$i];
			
		}
		
  	echo '<tr class="';
			
		if($i % 2 > 0)
		{
		  echo 'altrow'; // alternate background color for even rows.

		} // ending if($i % 2 > 0)
		
		if ($haveData)
		{
			echo '" id="' . $beer['id'];
			
		}
			
		echo '">' . "\n";

		if($config[ConfigNames::ShowTapNumCol])
		{
      /*********************************************************************************
      *     Tap number data.
      **********************************************************************************/
	    echo '<td class="tap-num"><span class="tapcircle">' . $i . '</span></td>' . "\n";

		} // ending if($config[ConfigNames::ShowTapNumCol])
			
    if($config[ConfigNames::ShowSrmCol])
		{
      /*********************************************************************************
      *     SRM data.
      **********************************************************************************/
      echo '<td class="srm">';

		  if ($haveData)
		  {
			  echo '<h3>' . $beer['og'] . ' OG</h3>';
        $ebc = $beer['srm'];
        $srmImgClass = "";
        $workEBC = (int) $ebc;
        $srmImgClass = ($workEBC < 36) ? "srm-" . ($workEBC - 1) : "srm-36"; 
			
		  }
			
      echo '<div class="srm-container"><div class="srm-indicator"><div class="srm-indicator';
			
		  if ($haveData)
		  {
			  echo ' ' . $srmImgClass;
			
		  }
			
			echo '"></div></div></div>';
			
		  if ($haveData)
		  {
			  echo '<h2>' . $beer['srm'] . ' SRM</h2>';
			
		  }
			
			echo '</td>' . "\n";

    } // ending if($config[ConfigNames::ShowSrmCol])

    if($config[ConfigNames::ShowIbuCol])
	  {
      /*********************************************************************************
      *     IBU data.
      **********************************************************************************/
			echo '<td class="ibu">';

		  if ($haveData)
		  {
			  $output = ($beer['og'] > 1) ? number_format((($beer['ibu'])/(($beer['og']-1)*1000)), 2, '.', '') : '0.00';
		    $output2 = ($beer['ibu'] > 100) ? 100 : $beer['ibu'];
				echo '<h3>' . $output .' BU:GU</h3>';
			
		  }
			
			echo '<div class="ibu-container"><div class="ibu-indicator"><div class="ibu-full" style="height:'; 
			$output = ($haveData) ? $output2 : '0';
			
			echo $output;
			echo '%"></div></div></div>';
			
			if ($haveData)
			{
				echo '<h2>' . $beer['ibu'] . ' IBU</h2>';
				
			}
			
			echo '</td>' . "\n";

    } // ending if($config[ConfigNames::ShowIbuCol])
		
    /*********************************************************************************
    *     Beer name data.
    **********************************************************************************/
    echo '<td class="name"><h1>';
		echo ($haveData) ? $beer['beername'] : 'Nothing on tap';
		echo '</h1><h2 class="subhead">';

		if ($haveData)
		{
			echo str_replace("_","",$beer['style']);
				
		}
		
		echo '</h2>';
		
		if ($haveData)
		{
			echo '<p>' . $beer['notes'] . '</p>';
				
		}
		
		echo '</td>' . "\n";
							
		if($config[ConfigNames::ShowAbvCol])
		{
    /*********************************************************************************
    *     ABV data.
    **********************************************************************************/
		  $showABVImage = ($config[ConfigNames::ShowAbvImg]) ? true : false;
			echo '<td class="abv">';
				
			if ($haveData)
			{
			  if (($beer['og'] == 1) && ($beer['fg'] == 1))
			  {
			    $calfromalc = 0;
				  $calfromcarbs = 0;

			  }
				
			  else
			  {
          $calfromalc = (1881.22 * ($beer['fg'] * ($beer['og'] - $beer['fg'])))/(1.775 - $beer['og']);
			    $calfromcarbs = 3550.0 * $beer['fg'] * ((0.1808 * $beer['og']) + (0.8192 * $beer['fg']) - 1.0004);
					
		  	} // ending else to if (($beer['og'] == 1) && ($beer['fg'] == 1))
				
			  echo '<h3>' . number_format($calfromalc + $calfromcarbs) . ' kCal</h3>';
				
			} // ending if ($haveData)	
				
			echo '<div class="abv-container">';
			
			if ($haveData)
			{
				$abv = ($beer['og'] - $beer['fg']) * 131;
				$numCups = 0;
				$remaining = $abv * 20;

        if ($showABVImage)
				{
				  do
				  {
					  $level = ($remaining < 100) ? $remaining : 100;
            echo '<div class="abv-indicator"><div class="abv-full" style="height:' . $level . '%"></div></div>';
					  $remaining = $remaining - $level;
					  $numCups++;

				  }while($remaining > 0 && $numCups < 2);
												
				  if($remaining > 0)
				  {
				    echo '<div class="abv-offthechart"></div>' . "\n";

				  } // ending if($remaining > 0)
				} // ending if ($showABVImage)
				
				else
				{
				  echo '<div class="abv">';
						
				} // ending else to if ($showABVImage)
			} // ending if ($haveData)
			
			else
			{
				if ($showABVImage)
				{
          echo '<div class="abv-indicator"><div class="abv-full" style="height:0%"></div></div>';
					
				} // ending if ($showABVImage)
			} // ending else to if ($haveData)

			echo '</div>';
			
			if ($haveData)
			{
				echo '<h2>' . number_format($abv, 1, '.', ','). '% ABV</h2>';
				
			}	// ending if ($haveData)
									
			echo '</td>' . "\n";
    } // ending if($config[ConfigNames::ShowAbvCol])
							
    if($config[ConfigNames::ShowKegCol])
		{
    /*********************************************************************************
    *     Keg data.
    **********************************************************************************/
		  echo '<td class="keg">';
			
			if ($haveData)
			{
		    echo '<h3>' . number_format((($beer['startAmount'] - $beer['remainAmount']) * 128)) . ' fl oz poured</h3>';

        /*********************************************************************************
        *     Code for new kegs that are not full.
        **********************************************************************************/
        $tid = $beer['id'];
        $sql = "Select kegId from taps where id=".$tid." limit 1";
        $kegID = mysqli_query($link, $sql);
        $kegID = mysqli_fetch_array($kegID);
        mysqli_free_result($sql); // added new as this wasn't being done.

        $sql = "SELECT `kegTypes`.`maxAmount` as kVolume FROM  `kegs`,`kegTypes` where  kegs.kegTypeId = kegTypes.id and kegs.id =".$kegID[0]."";
        $kvol = mysqli_query($link, $sql);
        $kvol = mysqli_fetch_array($kvol);
        mysqli_free_result($sql); // added new as this wasn't being done.

        $kvol = $kvol[0];
        $kegImgClass = "";
        $percentRemaining = ($beer['startAmount']>=$kvol) ? $beer['remainAmount'] / $beer['startAmount'] * 100 : $beer['remainAmount'] / $kvol * 100; 

				if($beer['remainAmount'] <= 0)
				{
				  $kegImgClass = "keg-empty";
					$percentRemaining = 100;
					
				}
				
        else
				{
					switch (true)
					{
						case $percentRemaining < 15:
						  $kegImgClass = "keg-red";
						  break;
						
						case $percentRemaining < 25:
						  $kegImgClass = "keg-orange";
						  break;
						
						case $percentRemaining < 45:
						  $kegImgClass = "keg-yellow";
						  break;
						
						case $percentRemaining < 100:
						  $kegImgClass = "keg-green";
						  break;
							
						default:
						  $kegImgClass = "keg-full";
						  break;
						
					} // ending switch
				} // ending if($beer['remainAmount'] <= 0)
			} // ending if ($haveData)

      echo '<div class="keg-container"><div class="keg-indicator"><div class="keg-full ';
			echo ($haveData) ? $kegImgClass : 'keg-empty';
			echo '" style="height:';
			echo ($haveData) ? $percentRemaining : '0';
			echo '%"></div></div></div><h2>';
			echo ($haveData) ? number_format(($beer['remainAmount'] * 128)) : '0';
			echo ' fl oz left</h2></td>' . "\n";
		} // ending if($config[ConfigNames::ShowKegCol])
								
		echo '</tr>' . "\n";
  } // ending for($i = 1; $i <= $numberOfTaps; $i++)
	
	echo '</tbody></table></div></body></html>' . "\n";
?>