<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Installation Processor</title>
</head>
<body>
<?php
/*********************************************************************************
* Description: Installation processor.
*
* ----- Modification Log -----
*
*  Who: kaljade and Tobor_8thMan collaboration. Both are members of HBT. 
* When: January 2019
*  Why: Update the logic to successfully run in Debian 9.x, php 7.x and MariaDB 10.x.
*
**********************************************************************************/

ini_set('display_errors', 'On');
error_reporting(E_ALL | E_STRICT);

require_once __DIR__.'/sql_parse.php';

/*********************************************************************************
*     Process and load form data from caller.
**********************************************************************************/
$servername = $_POST['servername'];
$dbRootUsername = $_POST['dbRootUsername'];
$dbRootPassword = $_POST['dbRootPassword'];
$dbuser = $_POST['dbuser'];
$dbpass1 = $_POST['dbpass1'];
$dbpass2 = $_POST['dbpass2'];
$adminuser = $_POST['adminuser'];
$adminpass1 = $_POST['adminpass1'];
$adminpass2 = $_POST['adminpass2'];
$action = $_POST['selectaction'];
$adminname = $_POST['adminname'];
$adminemail = $_POST['adminemail'];

/*********************************************************************************
*     Create the MD5 hash value for the admin password.
**********************************************************************************/
$adminhash = md5($adminpass1);

/*********************************************************************************
*     Do some validation on the input values.
**********************************************************************************/
$validerror ='';

echo 'Validating Entries...<br />';
flush();

/*********************************************************************************
*     Validate DB password.
**********************************************************************************/
if ($dbpass1 != $dbpass2)
{
  $validerror .= '<strong>The Database passwords do not match.</strong><br />';

} // ending if ($dbpass1 != $dbpass2)

/*********************************************************************************
*     Validate admin password.
**********************************************************************************/
if ($adminpass1 != $adminpass2)
{
  $validerror .= '<strong>The Administrator account passwords do not match.</strong><br />';

} // ending if ($adminpass1 != $adminpass2)

echo 'Success!<br />';
flush();

/*********************************************************************************
*     Validate DB connectivity.
**********************************************************************************/
echo 'Checking DB connectivity...';
flush();
$con=mysqli_connect($servername,$dbRootUsername,$dbRootPassword);

if (mysqli_connect_errno())
{
  $validerror .= '<strong>Cannot connect the the database using the supplied information.</strong><br />';

} // ending if (mysqli_connect_errno())

echo 'Success!<br/>';
flush();

/*********************************************************************************
*     Validate that the config directories are writable.
**********************************************************************************/
echo 'Checking config folder permissions...';
flush();

if (!is_writable(dirname('../../includes/functions.php')))
{
  $validerror .= '<strong>Cannot write the configuration files. Please check the /includes/ folder permissions. See the RPints Installation page on www.raspberrypints.com.</strong><br />';

} // ending if (!is_writable(dirname('../../includes/functions.php')))

if (!is_writable(dirname('../../admin/includes/checklogin.php')))
{
  $validerror .= '<strong>Cannot write the configuration files. Please check the /admin/includes/ folder permissions. See the RPints Installation page on www.raspberrypints.com.</strong><br />';

} // ending if (!is_writable(dirname('../../admin/includes/checklogin.php')))

echo 'Success!<br />';
flush();

//##TODO## Check if administrator account already exists

/*********************************************************************************
*     Display errors and quit processing.
**********************************************************************************/
if ($validerror != '') 
{
  echo '<html><body>';
  echo $validerror;
  echo '<br /><br />Please press the back button on your browser to fix these errors';
	echo '</body></html>';
  $action = 'skip';
  
} // ending if ($validerror !='')

/*********************************************************************************
*     Clear installation data routines. $action was determined and set in
* /install/index.php
**********************************************************************************/
if ($action == 'remove')
{
/*********************************************************************************
*     Processing remove.
**********************************************************************************/
	echo 'Deleting raspberrypints database...';
	flush();
	$sql = 'DROP database raspberrypints;';

	if (mysqli_query($con,$sql) === TRUE)
  {
	  echo 'Success!<br />';
    
  } // ending if (mysqli_query($con,$sql) === TRUE)
  
  else
  {
	  echo 'Failed. Description: ' . mysqli_error($con) . '<br />';
  
  } // ending else to if (mysqli_query($con,$sql) === TRUE)
  
	flush();
	echo 'Removing configuration files...';
	flush();

	try {
		// unlink deletes a file
	  unlink('../../includes/config.php');
	  unlink('../../admin/includes/conn.php');
	  unlink('../../admin/includes/configp.php');
    
	} // ending try

	catch (Exception $e) {
		echo 'Caught exception: ',  $e->getMessage(), '\n';
	} // ending catch
	
	echo 'Success!<br />';
	flush();
} // ending if ($action == 'remove')
	
if ($action == 'install')
{
/*********************************************************************************
*     Processing install.
**********************************************************************************/
  require_once __DIR__.'/config_files.php'; // includes the config_files.php file
	
  /*********************************************************************************
  *     Create the main config file.
  **********************************************************************************/
	echo 'Update config files...';
	flush();
	file_put_contents('../../includes/config.php', $mainconfigstring);
	echo "Success!<br />";
	flush();

  /*********************************************************************************
  *     Create the the admin files.
  **********************************************************************************/
	echo 'Update admin config files...';
	flush();
	file_put_contents('../../admin/includes/conn.php', $adminconfig1);
	file_put_contents('../../admin/includes/configp.php', $adminconfig2);
	echo 'Success!<br />';
	flush();

  /*********************************************************************************
  *     Create RPints User.
  **********************************************************************************/
	echo 'Creating RPints database user...<br />';
	flush();
	$sql = "GRANT ALL ON *.* TO '" . $dbuser . "'@'" . $servername . "' IDENTIFIED BY '" . $dbpass1 . "' WITH GRANT OPTION;";
  
	if (mysqli_query($con,$sql) === TRUE)
  {
	  echo 'Success!<br />';
    
  } // ending if (mysqli_query($con,$sql) === TRUE)
  
  else
  {
	  echo 'Failed. Description: ' . mysqli_error($con) . "<br />";
  
  } // ending else to if (mysqli_query($con,$sql) === TRUE)
  
	flush();

  /*********************************************************************************
  *     Run The Schema File.
  **********************************************************************************/
	echo 'Running Database Script...';
	flush();
	$dbms_schema = '../../sql/schema.sql';
	$sql_query = @fread(@fopen($dbms_schema, 'r'), @filesize($dbms_schema)) or die('Cannot find SQL schema file. ');
	$sql_query = remove_remarks($sql_query);
	$sql_query = remove_comments($sql_query);
	$sql_query = split_sql_file($sql_query, ';');

	foreach($sql_query as $sql){
    
	  if (mysqli_query($con,$sql) === FALSE)
    {
	    echo 'Failed. Description: ' . mysqli_error($con) . '<br />';
      die();
  
    } // ending if (mysqli_query($con,$sql) === FALSE)
	} // ending foreach($sql_query as $sql)

	echo 'Success!<br />';
	flush();

  /*********************************************************************************
  *     Add the admin user to the Users DB.
  **********************************************************************************/
	echo 'Adding new admin user...';
	flush();
	$currentdate = Date('Y-m-d H:i:s');
	$sql = "INSERT INTO users (username, password, name, email, createdDate, modifiedDate) VALUES ('" . $adminuser . "','" . $adminhash . "','" . $adminname . "','" . $adminemail . "','" . $currentdate . "','" . $currentdate . "');";

	if (mysqli_query($con,$sql) === TRUE)
  {
	  echo 'Success!<br />';
    
  } // ending if (mysqli_query($con,$sql) === TRUE)
  
  else
  {
	  echo 'Failed. Description: ' . mysqli_error($con) . '<br />';
  
  } // ending else to if (mysqli_query($con,$sql) === TRUE)

	flush();
	
  /*********************************************************************************
  *     Delete the original index.html page.
  **********************************************************************************/
	echo 'Deleting default index.html page...';
	flush();

	if (!unlink('../../index.html'))
	{
		echo ('File already deleted<br />');
		
  } // ending if (!unlink('../../index.html'))

	else
  {
	  echo ('Success!<br />');

	} // ending else to if (!unlink('../../index.html'))

	flush();
	
	if(!empty($_POST['sampledata'])) 
	{
    /*********************************************************************************
    *     Load the sample data.
    **********************************************************************************/
		echo 'Adding sample data...';
		flush();
			
		$dbms_schema = '../../sql/test_data.sql';
		$sql_query = @fread(@fopen($dbms_schema, 'r'), @filesize($dbms_schema)) or die('Cannot find SQL schema file. ');
		$sql_query = remove_remarks($sql_query);
		$sql_query = remove_comments($sql_query);
		$sql_query = split_sql_file($sql_query, ';');

		foreach($sql_query as $sql){
	    if (mysqli_query($con,$sql) === FALSE)
      {
	      echo 'Failed. Description: ' . mysqli_error($con) . '<br />';
        die();
  
      } // ending if (mysqli_query($con,$sql) === FALSE)
		} // ending foreach($sql_query as $sql)
			
			echo 'Success!<br />';
			flush();
	} // ending if(!empty($_POST['sampledata']))
} // ending if ($action == 'install')

if ($action !== 'remove' && $action !== 'skip')
{
	echo '<br /><br /><br /><h3> Congratulations! Raspberry Pints successfully installed.<br />';
	echo 'Click for - <a href="../../index.php">Tap List</a><br />';
	echo 'Click for - <a href="../../admin/index.php">Administration </a><br />';

} // ending if ($action !== 'remove' && $action !== 'skip')

/*********************************************************************************
*     Close the database connection.
**********************************************************************************/
mysqli_close($con);

?>
</body>
</html>