<?php
/*********************************************************************************
* Description: Config files for V2.1.0.000
*
* ----- Modification Log -----
*
*  Who: kaljade and Tobor_8thMan collaboration. Both are members of HBT. 
* When: January 2019
*  Why: Update the logic to successfully run in Debian 9.x, php 7.x and MariaDB 10.x.
*
**********************************************************************************/
	
/*********************************************************************************
*     Main config files - /includes/config.php
**********************************************************************************/
	$mainconfigstring = "<?php \n";
	$mainconfigstring .= "    function dbRPintsConnect() {\n";
	$mainconfigstring .= '        $link = ';
	$mainconfigstring .= "mysqli_connect('$servername', '$dbuser', '$dbpass1', 'raspberrypints');\n";
	$mainconfigstring .= 'return $link;' . "\n";
	$mainconfigstring .= "	}\n";
	$mainconfigstring .= '    $rpintsversion="2.1.0.000";' . "\n";
	$mainconfigstring .= '?>';
	
/*********************************************************************************
*     Admin config file - /admin/includes/conn.php 
**********************************************************************************/
	$adminconfig1 = "<?php \n";
	$adminconfig1 .= '   $host="' . "{$servername}" . '"; // Host name' . "\n";
	$adminconfig1 .= '   $username="' . "{$dbuser}" . '"; // Mysql username' . "\n";
	$adminconfig1 .= '   $password="' . "${dbpass1}" . '"; // Mysql password' . "\n";
	$adminconfig1 .= '   $db_name="raspberrypints"; // Database name' . "\n";
	$adminconfig1 .= '   $tbl_name="users";' . "\n";
	$adminconfig1 .= '   //Connect to server and select databse.' . "\n";
	$adminconfig1 .= '   $adminLink = mysqli_connect("$host", "$username", "$password", "$db_name");' . "\n";
	$adminconfig1 .= '   if (mysqli_connect_errno()) die("cannot select DB");' . "\n";
	$adminconfig1 .= '?>';
	
/*********************************************************************************
*     Admin config file - /admin/includes/configp.php 
**********************************************************************************/
	$adminconfig2 = "<?php\n";
	$adminconfig2 .= '  $dbhost="' . "{$servername}" . '";' . "\n";
	$adminconfig2 .= '	$dbname ="raspberrypints";' . "\n";
	$adminconfig2 .= '  $dbuser="' . "{$dbuser}" . '";' . "\n";
	$adminconfig2 .= '  $dbpass="' . "${dbpass1}" . '";' . "\n";
	$adminconfig2 .= '	$conn = new PDO("mysql:host=$dbhost;dbname=$dbname",$dbuser,$dbpass);' . "\n";
	$adminconfig2 .= '	$stmt = $conn->prepare(' . "'SELECT * FROM config WHERE showOnPanel = 1')" . ";\n";
	$adminconfig2 .= '	$stmt->execute();' . "\n";
	$adminconfig2 .= '	$result = $stmt->fetchAll();' . "\n";
	$adminconfig2 .= '?>';
?>