<?php
/*********************************************************************************
* Description: The main install file. Surf to this file to do the Raspberry Pints
*              install.
*
* ----- Modification Log -----
*
*  Who: kaljade and Tobor_8thMan collaboration. Both are members of HBT. 
* When: January 2019
*  Why: Update the logic to successfully run in Debian 9.x, php 7.x and MariaDB 10.x.
*
**********************************************************************************/
?>
<html>
	<script type="text/javascript">
		function checkPasswordMatch()
		{
      $message = ($("#txtNewPassword").val() != $("#txtConfirmPassword").val()) ? "Passwords do not match!" : "Passwords match.";
      $("#divCheckPasswordMatch").text($message);

		} // ending function checkPasswordMatch()
    
		function checkAdminPasswordMatch()
	  {
      $message = ($("#txtCheckAdminPassword").val() != $("#txtConfirmAdminPassword").val()) ? "Passwords do not match!" : "Passwords match.";
      $("#divCheckAdminPasswordMatch").text($message);

		} // ending function checkAdminPasswordMatch()

		function validateForm()
		{
		  if ($("#servername").val().length > 0 &&
		      $("#dbRootUsername").val().length > 0 &&
			    $("#dbRootPassword").val().length > 0 &&
			    $("#dbuser").val().length > 0 && 
			    $("#txtNewPassword").val().length > 0 &&
			    $("#txtConfirmPassword").val().length > 0 &&
			    $("#adminuser").val().length > 0 && 
			    $("#txtCheckAdminPassword").val().length > 0 && 
			    $("#txtConfirmAdminPassword").val().length > 0 && 
			    $("#adminname").val().length > 0 && 
			    $("#adminemail").val().length > 0 && 
			    $("#txtNewPassword").val() == $("#txtConfirmPassword").val() &&
			    $("#txtCheckAdminPassword").val() == $("#txtConfirmAdminPassword").val())
      {
		 	  $("#setupForm").submit();

			} // ending if statement
			
			else
			{
				window.alert("Please provide required values");

			}
		
		} // ending function validateForm()

		$(document).ready(function () {
		  $("#txtConfirmPassword").keyup(checkPasswordMatch);
		  $("#txtConfirmAdminPassword").keyup(checkAdminPasswordMatch);

		});
	</script>

	<head>
	  <title>RaspberryPints Installation</title>
	  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	  <!-- Set location of Cascading Style Sheets and script files -->
	  <link rel="stylesheet" type="text/css" href="styles.css" />
	  <link rel="shortcut icon" href="../img/pint.ico" />
	  <script type="text/javascript" src="includes/jquery-2.1.0.min.js"></script>	
	  <script src="includes/jquery.validate.js"></script>
    <META HTTP-EQUIV="Pragma" CONTENT="no-cache">
	  <META HTTP-EQUIV="Expires" CONTENT="-1">
  </head>
  <body>
    <h1>Welcome to Raspberry Pints!</h1>
    All values are required.

    <form id="setupForm" action="includes/configprocessor.php" method="post">
	    <?php
		    $upgrade=0;
		    $clear=0;
    
		    if (file_exists('../includes/config.php'))
        {
          /*********************************************************************************
          *     Install was already done. 
          **********************************************************************************/
		      echo 'We noticed that you already have installed RPints. Please select an option from the menu below';
			    // Check versions
			    require '../includes/config.php';
			    dbRPintsConnect(); //function dbRPintsConnect() is in includes/config.php dbRPintsConnect() sets $link connection
			    $sql = 'SELECT configValue FROM config where configName = "version"';
			    $queryResult = mysqli_query($link, $sql);
      
          $row = mysqli_fetch_assoc($queryResult);
          $dbversion = $row->configValue;
          mysqli_free_result($queryResult);
      
			    echo '<br /><select name="selectaction">';
      
			    if ($dbversion != $rpintsversion) {
          /*********************************************************************************
          *     Versions are different. We have an update. 
          **********************************************************************************/
				    echo '<option value="upgrade">Upgrade</option>';
			  	  $upgrade=1;
        
			    } // ending if ($dbversion != $rpintsversion)
        
			    echo '<option value="remove">Clear Data</option>';
			    $clear=1;
		      echo '</select>';
		      mysqli_close($link); // we opened the database in dbRPintsConnect and we must close it.
      
		    } // ending if (file_exists("../includes/config.php"))
      
		    else
		    {
          // Have a new install situation
		      echo '<input type="hidden" name="selectaction" value="install">';
      
	      } // ending else to if (file_exists("../includes/config.php"))
	    ?> 
  
      <h3>Step<span class="tapcircle">1</span></h3>
        In order to get started, we'll need a little information. 
        Was a MariaDB user created with root privlidges and given a password? If not, please exit from this installation and create the username and password.
        Enter that here for us to configure Raspberry Pints. Leave the Database Server name as the default, unless
        certain a change is needed.
	    <table>
			  <tr>
				  <td><label><strong>Database Server:</strong></label></td>
				  <td><input minlength="2" required class="inputbox" value="localhost" type="text" id="servername" name="servername"></td>
			  </tr>
			  <tr>
				  <td>
					  <label><strong>MariaDB Username with Root Abilities: (Needed to configure the database)</strong></label>
					  <br />If the MariaDB root password wasn't created<br />
					        please exit this Setup, open a terminal command,<br />
                  run mysql, then do a create user specifying username<br />
					        and password and grant all privileges.
				  </td>
				  <td><input class="inputbox" required type="text" id="dbRootUsername" name="dbRootUsername"></td>
			  </tr>
			  <tr>
				  <td><label><strong>MariaDB Username Root Password: (Needed to configure the database)</strong></label></td>
				  <td><input class="inputbox" required type="password" id="dbRootPassword" name="dbRootPassword"></td>
			  </tr>
		  </table>
	    <br />
	    <div id="sectiondb"<?php if ($clear==1){echo "style='display:none'";};?>>
	      <h3>Step<span class="tapcircle">2</span></h3>
		      Create the database user for Raspberry Pints to use. The default is "beers". It's OK to keep the default if desired.
		      This database account is just used by the software to access the database. This is not the administration account.
		    <table>
			    <tr>
				    <td><label><strong>Database Username:</strong></label></td>
				    <td><input class="inputbox" value="beers" id="dbuser" name="dbuser"></td>
			    </tr>
			    <tr>
				    <td><label><strong>Database User Password:</strong></label></td>
				    <td><input class="inputbox" id="txtNewPassword" type="password" name="dbpass1"></td>
			    </tr>
			    <tr>
				    <td><label><strong>Confirm Password:</strong></label></td>
				    <td><input class="inputbox" id="txtConfirmPassword" type="password" name="dbpass2" onChange="checkPasswordMatch();"></td>
				    <td><div class="registrationFormAlert" id="divCheckPasswordMatch"></div></td>
			    </tr>
		    </table>
		    <br />
		    <br />
		  </div>
		  <div id="sectionrpints"<?php if ($clear==1){echo "style='display:none'";};?>>
		    <h3>Step<span class="tapcircle">3</span></h3>
				  And at last, we'll need to create a management account. this account is used for adding / removing beers, etc. AKA, the Raspberry Pints Admin account.
		    <table>
			    <tr>
				    <td><label><strong>Raspberry Pints Admin Username:</strong></label></td>
				    <td><input class="inputbox" value="admin" id="adminuser" name="adminuser"></td>
			    </tr>
			    <tr>
				    <td><label><strong>Raspberry Pints Admin Password:</strong></label></td>
				    <td><input class="inputbox" id="txtCheckAdminPassword" type="password" name="adminpass1"></td>
			    </tr>
			    <tr>
				    <td><label><strong>Confirm Password:</strong></label></td>
				    <td><input class="inputbox" id="txtConfirmAdminPassword" type="password" name="adminpass2" onChange="checkAdminPasswordMatch();"></td>
				    <td><div class="registrationFormAlert" id="divCheckAdminPasswordMatch"></div></td>
			    </tr>
			    <tr>
				    <td><label><strong>Email Address:</strong></label></td>
				    <td><input class="inputbox" name="adminemail" id="adminemail"></td>
			    </tr>
			    <tr>
				    <td><label><strong>Your Name (webmaster name):</strong></label></td>
				    <td><input class="inputbox" id="adminname" name="adminname"></td>
			    </tr>
		    </table>
		    <br />
		    <br />
		    Desire to load sample data? If so, please check the box below. This gives a demo of what the system does without having to
		    type in all the information. It's not that difficult to add beers, so the default is not to load sample data.
		    <br />
		    <br />
		    <input type="checkbox" name="sampledata" value="Yes"><strong>Load sample data?</strong>
		    <br />
		    <br />
		    <br />
		  </div>
		  <input class="btn" id="setupButton" type="button" value="Setup!" onclick="validateForm();">
	  </form>
  </body>
</html>