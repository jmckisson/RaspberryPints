<?php
/*********************************************************************************
* Description: Send password form.
*
* ----- Modification Log -----
*
*  Who: kaljade and Tobor_8thMan collaboration. Both are members of HBT. 
* When: January 2019
*  Why: Update the logic to successfully run in Debian 9.x, php 7.x and MariaDB 10.x.
*
**********************************************************************************/
session_start(); // php command creates a session or resumes the current one based on a session identifier passed via a GET or POST request, or passed via a cookie.
require 'conn.php'; // $adminLink is set with the connection

// Get values from form 
$password=md5($_POST['password']);
$email=($_POST['email']);
	
// update data in mysql database
$sql="UPDATE users SET password='$password' WHERE email='$email'";
$result=mysqli_query($adminLink, $sql);

// if successfully updated.
if($result)
{
  echo "Successful<br /><script>location.href='../index.php';</script>";

}
else
{
  echo "ERROR";

}

mysqli_free_result($qry); // added new as this wasn't being done.

?> 
