<?php
/*********************************************************************************
* Description: Beer Style Manager class.
*
* ----- Modification Log -----
*
*  Who: kaljade and Tobor_8thMan collaboration. Both are members of HBT. 
* When: January 2019
*  Why: Update the logic to successfully run in Debian 9.x, php 7.x and MariaDB 10.x.
*
**********************************************************************************/

require_once __DIR__.'/../models/beerStyle.php';

class BeerStyleManager
{

	function GetAll($connectionLink)
	{
		$sql="SELECT * FROM beerStyles ORDER BY name";

		$qry = mysqli_query($connectionLink, $sql);
		
		$beerStyles = array();

		while($i = mysqli_fetch_assoc($qry)){
			$beerStyle = new beerStyle();
			$beerStyle->setFromArray($i);
			$beerStyles[$beerStyle->get_id()] = $beerStyle;

		} // ending while
		
		// $qry is never freed. Free it.
		mysqli_free_result($qry);

		return $beerStyles;
	} // ending function GetAll()

	function GetById($connectionLink, $id)
	{
		$sql="SELECT * FROM beerStyles WHERE id = $id";

    $qry = mysqli_query($connectionLink, $sql);
		
		if( $i = mysqli_fetch_array($qry) ){
			$beerStyle = new beerStyle();
			$beerStyle->setFromArray($i);
			return $beerStyle;

		} // ending if

		// $qry is never freed. Free it.
		mysqli_free_result($qry);
		
		return null;
	} // ending function GetById($id)
} // ending class BeerStyleManager