<?php
/*********************************************************************************
* Description: Keg Type Manager class.
*
* ----- Modification Log -----
*
*  Who: kaljade and Tobor_8thMan collaboration. Both are members of HBT. 
* When: January 2019
*  Why: Update the logic to successfully run in Debian 9.x, php 7.x and MariaDB 10.x.
*
**********************************************************************************/
require_once __DIR__.'/../models/kegType.php';

class KegTypeManager
{

	function GetAll($connectionLink)
	{
		$sql="SELECT * FROM kegTypes ORDER BY displayName";
    $qry = mysqli_query($connectionLink, $sql);
		
		$kegTypes = array();

		while($i = mysqli_fetch_array($qry)){
			$kegType = new KegType();
			$kegType->setFromArray($i);
			$kegTypes[$kegType->get_id()] = $kegType;

		} // ending while

		mysqli_free_result($qry); // added new as this wasn't being done.
		
		return $kegTypes;
	} // ending function GetAll()
			
	function GetById($connectionLink, $id)
	{
		$sql="SELECT * FROM kegTypes WHERE id = $id";
    $qry = mysqli_query($connectionLink, $sql);
		
		if( $i = mysqli_fetch_array($qry) ){		
			$kegType = new KegType();
			$kegType->setFromArray($i);
			return $kegType;
		}

		mysqli_free_result($qry); // added new as this wasn't being done.
		return null;

	} // ending function GetById($id)
} // ending class KegTypeManager