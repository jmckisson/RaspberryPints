<?php
/*********************************************************************************
* Description: Keg Status Manager class.
*
* ----- Modification Log -----
*
*  Who: kaljade and Tobor_8thMan collaboration. Both are members of HBT. 
* When: January 2019
*  Why: Update the logic to successfully run in Debian 9.x, php 7.x and MariaDB 10.x.
*
**********************************************************************************/
require_once __DIR__.'/../models/kegStatus.php';

class KegStatusManager
{

	function GetAll($connectionLink)
	{
		$sql="SELECT * FROM kegStatuses ORDER BY name";
    $qry=mysqli_query($connectionLink, $sql); 
		
		$kegStatuses = array();

		while($i = mysqli_fetch_array($qry)){
			$kegStatus = new KegStatus();
			$kegStatus->setFromArray($i);
			$kegStatuses[$kegStatus->get_code()] = $kegStatus;

		} // ending while

		mysqli_free_result($qry); // added new as this wasn't being done.

		return $kegStatuses;

	}	// ending function GetAll()
		
	function GetByCode($connectionLink, $code)
	{
		$sql="SELECT * FROM kegStatuses WHERE code = '$code'";
    $qry=mysqli_query($connectionLink, $sql); 
		
		if( $i = mysqli_fetch_array($qry) ){		
			$kegStatus = new KegStatus();
			$kegStatus->setFromArray($i);
			return $kegStatus;
		}

		mysqli_free_result($qry); // added new as this wasn't being done.
		return null;
	} // ending function GetByCode($code)
} // ending class KegStatusManager