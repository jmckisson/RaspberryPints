<?php
/*********************************************************************************
* Description: Tap Manager class.
*
* ----- Modification Log -----
*
*  Who: kaljade and Tobor_8thMan collaboration. Both are members of HBT. 
* When: January 2019
*  Why: Update the logic to successfully run in Debian 9.x, php 7.x and MariaDB 10.x.
*
**********************************************************************************/
require_once __DIR__.'/../../../includes/config_names.php';
require_once __DIR__.'/../models/tap.php';

class TapManager
{
	
	function Save($connectionLink, $tap)
	{
		$sql="UPDATE kegs k SET k.kegStatusCode = 'SERVING', modifiedDate = NOW() WHERE id = " . $tap->get_kegId();
    mysqli_query($connectionLink, $sql);
	
		$sql="UPDATE taps SET active = 0, modifiedDate = NOW() WHERE active = 1 AND tapNumber = " . $tap->get_tapNumber();
		mysqli_query($connectionLink, $sql);
		
		if($tap->get_id()){
			$sql = 	"UPDATE taps " .
					"SET " .
						"beerId = " . $tap->get_beerId() . ", " .
						"kegId = " . $tap->get_kegId() . ", " .
						"tapNumber = " . $tap->get_tapNumber() . ", " .
						"pinId = " . $tap->get_pinId() . "," .
						"ogAct = " . $tap->get_og() . ", " .
						"fgAct = " . $tap->get_fg() . ", " .
						"srmAct = " . $tap->get_srm() . ", " .
						"ibuAct = " . $tap->get_ibu() . ", " .
						"startAmount = " . $tap->get_startAmount() . ", " .
						"active = " . $tap->get_active() . ", " .
						"modifiedDate = NOW() ".
					"WHERE id = " . $tap->get_id();
					
		}
		else
		{
			$sql = 	"INSERT INTO taps(beerId, kegId, tapNumber,pinId, ogAct, fgAct, srmAct, ibuAct, startAmount, currentAmount, active, createdDate, modifiedDate ) " .
					"VALUES(" . $tap->get_beerId() . ", " . $tap->get_kegId() . ", " . $tap->get_tapNumber() . "," . $tap->get_pinId() . ", " . $tap->get_og() . ", " . $tap->get_fg() . ", " . $tap->get_srm() . ", " . $tap->get_ibu() . ", " . $tap->get_startAmount() . ", " . $tap->get_startAmount() . ", " . $tap->get_active	() . ", NOW(), NOW())";
		
		} // ending if		
		
		mysqli_query($connectionLink, $sql);

	} // ending function Save($tap)
	
	function GetById($connectionLink, $id)
  {
		$id = (int) preg_replace('/\D/', '', $id);
	
		$sql="SELECT * FROM taps WHERE id = $id";
		$qry = mysqli_query($connectionLink, $sql);
		
		if( $i = mysqli_fetch_array($qry) ){
			$tap = new Tap();
			$tap->setFromArray($i);
			return $tap; 

		}

		mysqli_free_result($qry); // added new as this wasn't being done.
	
		return null;
	} // ending function GetById($id)

	function updateTapNumber($connectionLink, $newTapNumber)
  {
		$sql="UPDATE config SET configValue = $newTapNumber, modifiedDate = NOW() WHERE configName = '".ConfigNames::NumberOfTaps."'";
    mysqli_query($connectionLink, $sql);

		$sql="UPDATE kegs SET kegStatusCode = 'SANITIZED', modifiedDate = NOW() WHERE id IN (SELECT kegId FROM Taps WHERE tapNumber > $newTapNumber AND active = 1) ";
    mysqli_query($connectionLink, $sql);
		
		$sql="UPDATE taps SET active = 0, modifiedDate = NOW() WHERE active = 1 AND tapNumber > $newTapNumber";
    mysqli_query($connectionLink, $sql);

	} // ending function updateTapNumber($newTapNumber)

	function getTapNumber($connectionLink)
  {
		$sql="SELECT configValue FROM config WHERE configName = '".ConfigNames::NumberOfTaps."'";
    $qry = mysqli_query($connectionLink, $sql);
		$config = mysqli_fetch_array($qry);
		mysqli_free_result($qry); // added new as this wasn't being done.
		
		if( $config != false )
    {
			return $config['configValue'];

		}
	} // ending function getTapNumber

	function getActiveTaps($connectionLink)
  {
		$sql="SELECT * FROM taps WHERE active = 1";
    $qry = mysqli_query($connectionLink, $sql);
		
		$taps = array();

		while($i = mysqli_fetch_array($qry)){
			$tap = new Tap();
			$tap->setFromArray($i);
			$taps[$tap->get_tapNumber()] = $tap;

		}

		mysqli_free_result($qry); // added new as this wasn't being done.
		
		return $taps;

	} // ending function getActiveTaps()
	
	function closeTap($connectionLink, $id)
  {
		$sql="UPDATE taps SET active = 0, modifiedDate = NOW() WHERE id = $id";
    mysqli_query($connectionLink, $sql);
		
		$sql="UPDATE kegs k, taps t SET k.kegStatusCode = 'NEEDS_CLEANING' WHERE t.kegId = k.id AND t.Id = $id";
    mysqli_query($connectionLink, $sql);

	} // ending function closeTap($id)
} // ending class TapManager