<?php
/*********************************************************************************
* Description: Beer Manager class.
*
* ----- Modification Log -----
*
*  Who: kaljade and Tobor_8thMan collaboration. Both are members of HBT. 
* When: January 2019
*  Why: Update the logic to successfully run in Debian 9.x, php 7.x and MariaDB 10.x.
*
**********************************************************************************/
require_once __DIR__.'/../models/beer.php';

class BeerManager
{

	function Save($connectionLink, $beer)
	{
		$sql = "";

		if($beer->get_id()){
			$sql = 	"UPDATE beers " .
					"SET " .
						"name = '" . encode($beer->get_name()) . "', " .
						"beerStyleId = '" . encode($beer->get_beerStyleId()) . "', " .
						"notes = '" . encode($beer->get_notes()) . "', " .
						"ogEst = '" . $beer->get_og() . "', " .
						"fgEst = '" . $beer->get_fg() . "', " .
						"srmEst = '" . $beer->get_srm() . "', " .
						"ibuEst = '" . $beer->get_ibu() . "', " .
						"modifiedDate = NOW() ".
					"WHERE id = " . $beer->get_id();
					
		} // ending if

		else
		{		
			$sql = 	"INSERT INTO beers(name, beerStyleId, notes, ogEst, fgEst, srmEst, ibuEst, createdDate, modifiedDate ) " .
					"VALUES(" . 
					"'" . encode($beer->get_name()) . "', " .
					$beer->get_beerStyleId() . ", " .
					"'" . encode($beer->get_notes()) . "', " .
					"'" . $beer->get_og() . "', " . 
					"'" . $beer->get_fg() . "', " . 
					"'" . $beer->get_srm() . "', " . 
					"'" . $beer->get_ibu() . "' " .
					", NOW(), NOW())";
		} // ending else to if
	
		mysqli_query($connectionLink, $sql);

	} // ending function Save($beer)
	
	function GetAll($connectionLink)
	{
		$sql="SELECT * FROM beers ORDER BY name";
		$qry = mysqli_query($connectionLink, $sql);
		
		$beers = array();

		while($i = mysqli_fetch_array($qry)){
			$beer = new Beer();
			$beer->setFromArray($i);
			$beers[$beer->get_id()] = $beer;

 		} // ending while

		mysqli_free_result($qry); // added new as this wasn't being done.

		return $beers;
	} // ending function GetAll
	
	function GetAllActive($connectionLink)
	{
		$sql="SELECT * FROM beers WHERE active = 1 ORDER BY name";

		$qry = mysqli_query($connectionLink, $sql);
		$beers = array();

		while($i = mysqli_fetch_assoc($qry)){
			$beer = new Beer(); // class in beer.php
			$beer->setFromArray($i); // function in class Beer (in beer.php)
			$beers[$beer->get_id()] = $beer;

		} // ending while
		
		mysqli_free_result($qry); // added new as this wasn't being done.

		return $beers;
	} // ending function GetAllActive()
		
	function GetById($connectionLink,$id)
	{
		$sql="SELECT * FROM beers WHERE id = $id";

    $qry = mysqli_query($connectionLink, $sql);
		
		if( $i = mysqli_fetch_array($qry) ){		
			$beer = new Beer();
			$beer->setFromArray($i);
			return $beer;

		} // ending if

		mysqli_free_result($qry); // added new as this wasn't being done.

		return null;
	} // ending function GetById($id)
	
	function Inactivate($connectionLink, $id)
	{
	  $sql = "SELECT * FROM taps WHERE beerId = $id AND active = 1";

    $qry = mysqli_query($connectionLink, $sql);
		
	  if( mysqli_fetch_array($qry) ){		
	    $_SESSION['errorMessage'] = "Beer is associated with an active tap and could not be deleted.";
		  return;

	  } // ending if
	
		$sql="UPDATE beers SET active = 0 WHERE id = $id";

    mysqli_query($connectionLink, $sql);
		mysqli_free_result($qry); // added new as this wasn't being done.
		
		$_SESSION['successMessage'] = "Beer successfully deleted.";
	} // ending function Inactivate($id)
} // ending class BeerManager