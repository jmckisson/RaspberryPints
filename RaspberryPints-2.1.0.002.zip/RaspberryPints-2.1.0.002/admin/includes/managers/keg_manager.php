<?php
/*********************************************************************************
* Description: Keg Manager class.
*
* ----- Modification Log -----
*
*  Who: kaljade and Tobor_8thMan collaboration. Both are members of HBT. 
* When: January 2019
*  Why: Update the logic to successfully run in Debian 9.x, php 7.x and MariaDB 10.x.
*
**********************************************************************************/
require_once __DIR__.'/../models/keg.php';

class KegManager
{

	function GetAll($connectionLink)
	{
		$sql="SELECT * FROM kegs ORDER BY label";

    $qry = mysqli_query($connectionLink, $sql);
		
		$kegs = array();

		while($i = mysqli_fetch_array($qry)){
			$keg = new Keg();
			$keg->setFromArray($i);
			$kegs[$keg->get_id()] = $keg;

		} // ending while

		mysqli_free_result($qry); // added new as this wasn't being done.
		
		return $kegs;
	} // ending function GetAll
	
	function GetAllActive($connectionLink)
	{
		$sql="SELECT * FROM kegs WHERE active = 1 ORDER BY label";
    $qry = mysqli_query($connectionLink, $sql);
		
		$kegs = array();

		while($i = mysqli_fetch_array($qry)){
			$keg = new Keg();
			$keg->setFromArray($i);
			$kegs[$keg->get_id()] = $keg;

		} // ending while

		mysqli_free_result($qry); // added new as this wasn't being done.
		
		return $kegs;
	} // ending function GetAllActive()
	
	function GetAllAvailable($connectionLink)
	{
		$sql="SELECT * FROM kegs WHERE active = 1
			AND kegStatusCode != 'SERVING'
			AND kegStatusCode != 'NEEDS_CLEANING'
			AND kegStatusCode != 'NEEDS_PARTS'
			AND kegStatusCode != 'NEEDS_REPAIRS'
		ORDER BY label";

    $qry = mysqli_query($connectionLink, $sql);
		
		$kegs = array();

		while($i = mysqli_fetch_array($qry)){
			$keg = new Keg();
			$keg->setFromArray($i);
			$kegs[$keg->get_id()] = $keg;

		} // ending while
		
		mysqli_free_result($qry); // added new as this wasn't being done.
		return $kegs;
	} // ending function GetAllAvailable()
			
	function GetById($connectionLink, $id)
	{
		$sql="SELECT * FROM kegs WHERE id = $id";
    $qry = mysqli_query($connectionLink, $sql);
		
		if( $i = mysqli_fetch_array($qry) ){		
			$keg = new Keg();
			$keg->setFromArray($i);
			return $keg;

		} // ending if

		mysqli_free_result($qry); // added new as this wasn't being done.
		return null;
	} // ending function GetById($id)
	
	
	function Save($connectionLink, $keg)
	{
		$sql = "";

		if($keg->get_id()){
			$sql = 	"UPDATE kegs " .
					"SET " .
						"label = '" . $keg->get_label() . "', " .
						"kegTypeId = " . $keg->get_kegTypeId() . ", " .
						"make = '" . $keg->get_make() . "', " .
						"model = '" . $keg->get_model() . "', " .
						"serial = '" . $keg->get_serial() . "', " .
						"stampedOwner = '" . $keg->get_stampedOwner() . "', " .
						"stampedLoc = '" . $keg->get_stampedLoc() . "', " .
						"weight = '" . $keg->get_weight() . "', " .
						"notes = '" . $keg->get_notes() . "', " .
						"kegStatusCode = '" . $keg->get_kegStatusCode() . "', " .
						"modifiedDate = NOW() ".
					"WHERE id = " . $keg->get_id();
					
		}
		else
		{
			$sql = 	"INSERT INTO kegs(label, kegTypeId, make, model, serial, stampedOwner, stampedLoc, weight, notes, kegStatusCode, createdDate, modifiedDate ) " .
					"VALUES(" . 
						"'". $keg->get_label() . "', " . 
						$keg->get_kegTypeId() . ", " . 
						"'". $keg->get_make() . "', " . 
						"'". $keg->get_model() . "', " . 
						"'". $keg->get_serial() . "', " . 
						"'". $keg->get_stampedOwner() . "', " . 
						"'". $keg->get_stampedLoc() . "', " . 
						"'". $keg->get_weight() . "', " . 
						"'". $keg->get_notes() . "', " . 
						"'". $keg->get_kegStatusCode() . "', " . 
						"NOW(), NOW())";
		}
		
		mysqli_query($connectionLink, $sql);

	} // ending function Save($keg)
	
	function Inactivate($connectionLink, $id)
	{
		$sql = "SELECT * FROM taps WHERE kegId = $id AND active = 1";
    $qry = mysqli_query($connectionLink, $sql);
		
		if( mysqli_fetch_array($qry) ){		
			$_SESSION['errorMessage'] = "Keg is associated with an active tap and could not be deleted.";
			return;

		}
	
		$sql="UPDATE kegs SET active = 0 WHERE id = $id";
		mysqli_query($connectionLink, $sql);
		
		$_SESSION['successMessage'] = "Keg successfully deleted.";

		mysqli_free_result($qry); // added new as this wasn't being done.

	} // ending function Inactivate($id)
} // ending class KegManager