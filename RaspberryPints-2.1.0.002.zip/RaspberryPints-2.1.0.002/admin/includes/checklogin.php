<?php
/*********************************************************************************
* Description: Check he entered admin username and password values. 
*
* ----- Modification Log -----
*
*  Who: kaljade and Tobor_8thMan collaboration. Both are members of HBT. 
* When: January 2019
*  Why: Update the logic to successfully run in Debian 9.x, php 7.x and MariaDB 10.x.
*
**********************************************************************************/
session_start(); // php command creates a session or resumes the current one based on a session identifier passed via a GET or POST request, or passed via a cookie. 

$session=session_id(); // php command used to get or set the session id for the current session
$time=time(); // php command
$time_check=$time-1800; //SET TIME 10 Minute

require 'conn.php'; // $adminLink is set with the connection

$_SESSION['loginFailed'] = false;

// username and password sent from calling form
$myusername=$_POST['myusername'];
$mypassword=md5($_POST['mypassword']);

// To protect MySQL injection (more detail about MySQL injection)
$myusername = stripslashes($myusername);
$mypassword = stripslashes($mypassword);
$myusername = mysqli_real_escape_string($adminLink, $myusername);
$mypassword = mysqli_real_escape_string($adminLink, $mypassword);

$sql="SELECT * FROM $tbl_name WHERE username='$myusername' and password='$mypassword'";

$result=mysqli_query($adminLink, $sql); //$result is never freed

$count=mysqli_num_rows($result);
mysqli_free_result($result);

// If result matched $myusername and $mypassword, table row must be 1 row
if($count==1)
{
  // Set session values and redirect to file "admin.php"
  $_SESSION['myusername'] =$myusername;
  $_SESSION['mypassword'] =$mypassword;
  echo "<script>location.href='../admin.php';</script>"; // if only 1 entry go to the admin screen

}
else
{
  $_SESSION['loginFailed'] = true;
  echo "<script>location.href='../index.php';</script>"; // more than 1 entry prompt for username and password

}
?>
