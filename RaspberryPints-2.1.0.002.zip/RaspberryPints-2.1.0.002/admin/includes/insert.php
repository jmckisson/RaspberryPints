<?php
/*********************************************************************************
* Description: Insert row into the beers database.
*
* ----- Modification Log -----
*
*  Who: kaljade and Tobor_8thMan collaboration. Both are members of HBT. 
* When: January 2019
*  Why: Update the logic to successfully run in Debian 9.x, php 7.x and MariaDB 10.x.
*
**********************************************************************************/

session_start(); // php command creates a session or resumes the current one based on a session identifier passed via a GET or POST request, or passed via a cookie.

if(!isset( $_SESSION['myusername'] )){
	//header("location:index.php");
}
require 'conn.php'; // $adminLink is set with the connection
require_once '../includes/functions.php';

$sql="INSERT INTO beers (name, style, notes, ogEst, fgEst, srmEst, ibuEst, modifiedDate) VALUES ('$_POST[name]','$_POST[style]','$_POST[notes]','$_POST[ogEst]','$_POST[fgEst]','$_POST[srmEst]','$_POST[ibuEst]', NOW())";

if (mysqli_query($adminLink, $sql) === TRUE)
{
	redirect('../beer_main.php');
	
} // ending if (mysqli_query($adminLink, $sql) === TRUE)

else
{
	die('Error: ' . mysqli_error($adminLink));

} // ending else to if (mysqli_query($adminLink, $sql) === TRUE)

// php is unterminated