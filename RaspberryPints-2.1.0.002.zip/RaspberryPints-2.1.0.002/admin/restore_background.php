<?php
/*********************************************************************************
* Description: Restore background portion of the Admin Portal.
*
* ----- Modification Log -----
*
*  Who: kaljade and Tobor_8thMan collaboration. Both are members of HBT. 
* When: January 2019
*  Why: Update the logic to successfully run in Debian 9.x, php 7.x and MariaDB 10.x.
*
**********************************************************************************/
  session_start();
	
  if(!isset( $_SESSION['myusername'] )){
    header("location:index.php");
		
  }

  $file = 'img/background.jpg';
  $newfile = '../img/background.jpg';

  if (!copy($file, $newfile)) {
	  echo "failed to copy $file...\n";
  }
  else {
    echo "<script>location.href='personalize.php';</script>";
  } 
?>
