<div id="footer">
	&copy; Copyright 2012-2019 RaspberryPints. kaljade and Tobor_8thMan collaboration updated to run in Debian 9.x, php 7.x and MariaDB 10.x 
</div> 
