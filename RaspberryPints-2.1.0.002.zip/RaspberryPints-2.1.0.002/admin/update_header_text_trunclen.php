<?php
/*********************************************************************************
* Description: Update the Tap List Text Truncation value.
*
* ----- Modification Log -----
*
*  Who: kaljade and Tobor_8thMan collaboration. Both are members of HBT. 
* When: January 2019
*  Why: Update the logic to successfully run in Debian 9.x, php 7.x and MariaDB 10.x.
*
**********************************************************************************/
  session_start(); // php command creates a session or resumes the current one based on a session identifier passed via a GET or POST request, or passed via a cookie.

  if(!isset( $_SESSION['myusername'] ))
  {
    header("location:index.php");

  }

  require 'includes/conn.php'; // $adminLink is set with the connection
  require '../includes/config_names.php';

  // Get values from form 
  $header_text_trunclen=$_POST['header_text_trunclen'];

  // update data in mysql database
  $sql="UPDATE config SET configValue='$header_text_trunclen' WHERE configName ='headerTextTruncLen'";
  $result=mysqli_query($adminLink, $sql);

  // if successfully updated.
  if($result)
  {
    echo "Successful<br /><script>location.href='personalize.php';</script>";

  }
  else
  {
    echo "ERROR";

  }

  mysqli_free_result($result); // added new as this wasn't being done.
?> 
